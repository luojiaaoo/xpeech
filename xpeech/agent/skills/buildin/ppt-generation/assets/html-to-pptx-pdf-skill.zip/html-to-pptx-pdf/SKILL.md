---
name: html-to-pptx-pdf
description: 当用户要求把 HTML 幻灯片、网页 deck 或逐页 HTML 转换为可编辑 PPTX、PDF 或两种格式时使用。在用户本地环境中调用 Playwright/Chromium：PPTX 采用 html2pptx + pptxgenjs 生成原生可编辑 PowerPoint 对象，PDF 使用 Chromium 打印并支持多文件 deck 合并。
---

# html-to-pptx-pdf

在用户本地环境中将 HTML deck 转换为可编辑 PPTX、PDF 或两种格式。不要在不提供本地 Playwright/Chromium 的远程服务中执行转换。

## 依赖

在使用脚本的项目目录安装：

```bash
npm install playwright pptxgenjs sharp pdf-lib
npx -y playwright install chromium
```

所有 `npx` 调用必须显式加 `-y`，避免首次下载包时停在交互确认。

需要 Python 验证脚本时安装：

```bash
pip install playwright
playwright install chromium
```

## 开始前

先确认用户需要 PDF、PPTX 还是两者。只有需要可编辑 PPTX 时，才必须完整读取 `references/editable-pptx.md` 并检查下列约束：

1. 文字放在 `<p>`、`<h1>`–`<h6>`、`<ul>`、`<ol>`、`<li>` 中，DIV 不含裸文字。
2. 不使用 CSS gradient。
3. 文字标签不承载 background、border 或 shadow，装饰放到外层 DIV。
4. DIV 不使用 `background-image`，图片写成 `<img>`。

只需 PDF 时不要为了迎合 PPTX 限制而破坏原有 HTML 视觉；PDF 路径使用 Chromium 打印，可保留 CSS 渐变、SVG 和 Web Component。

## 转换为 PPTX

逐页 HTML 放进同一目录，文件名按页面顺序编号：

```text
slides/
├── 01-cover.html
├── 02-agenda.html
└── 03-content.html
```

运行：

```bash
node scripts/export_deck_pptx.mjs --slides slides --out output/deck.pptx
```

`scripts/export_deck_pptx.mjs` 会调用 `scripts/html2pptx.js`，本地启动 Chromium，逐页把 HTML 元素翻译成 PowerPoint 文本框、形状和图片。

## 转换为 PDF

对 deck 入口运行：

```bash
node scripts/export_deck_pdf.mjs --html index.html --out output/deck.pdf
```

如果 `index.html` 定义了 `window.DECK_MANIFEST`，脚本会逐个打印其中的幻灯片，再合并为一份 PDF。对单文件 `<deck-stage>` deck，脚本会在打印前展开 Shadow DOM slot 中的所有页，保留每页的 flex/grid 布局并按页分隔。脚本默认从第一张 slide 或 `<deck-stage>` 自动检测画布尺寸；只在需要强制尺寸时同时传入 `--width` 和 `--height`。

## 验证 HTML

读取 `references/verification.md`，使用原版脚本：

```bash
python scripts/verify.py slides/01-cover.html --viewports 1280x720
python scripts/verify.py index.html --slides 10
```

验证截图、控制台 warning/error、页面异常、字体加载和溢出问题。转换失败时优先修 HTML，不要直接修改生成的 PPTX 掩盖源文件问题。

## 交付

- 用户请求的 `.pptx` 和/或 `.pdf`
- 原始 HTML 与图片资源
- 验证截图和已知字体回落说明

目标机器缺少 Web 字体时，PowerPoint/Keynote 可能发生字体回落与文本框溢出，必须提醒用户复查。

## 文件路由

| 任务 | 文件 |
|---|---|
| HTML 约束与错误速查 | `references/editable-pptx.md` |
| 本地浏览器验证 | `references/verification.md` + `scripts/verify.py` |
| HTML→PPTX 转换 | `scripts/html2pptx.js` |
| 批量导出 PPTX | `scripts/export_deck_pptx.mjs` |
| 导出 PDF | `scripts/export_deck_pdf.mjs` |
