# PDF/PPTX 本地转换验证

该技能包必须在用户本地环境中使用。先验证 HTML，再转换，最后分别验证 PDF/PPTX。

## 目录

1. 安装与非交互命令
2. HTML 预检
3. PDF 验证
4. PPTX 验证
5. 常见故障

## 安装与非交互命令

```bash
npm install playwright pptxgenjs sharp pdf-lib
npx -y playwright install chromium
pip install playwright
playwright install chromium
```

所有 `npx` 命令必须显式加 `-y`，避免首次下载时停在确认提示。

## HTML 预检

从技能包根目录运行：

```bash
python scripts/verify.py /absolute/path/to/slides/01-cover.html --viewports 1280x720
python scripts/verify.py /absolute/path/to/index.html --slides 10
```

检查：

- 浏览器无白屏，控制台无未解释 error。
- 字体和图片已加载，没有破图或意外 fallback。
- 页面没有溢出、裁切、重叠和额外滚动区。
- 多文件 deck 的文件名排序与 manifest 页序一致。
- 需要可编辑 PPTX 时，逐页通过 `references/editable-pptx.md` 的 DOM/CSS 约束。

## PDF 验证

导出：

```bash
node scripts/export_deck_pdf.mjs --html /absolute/path/to/index.html --out output/deck.pdf
```

脚本会自动检测画布。只在需要强制尺寸时同时传入：

```bash
node scripts/export_deck_pdf.mjs --html /absolute/path/to/index.html --out output/deck.pdf --width 1280 --height 720
```

验证：

- PDF 页数等于 HTML deck 页数。
- 首页、末页和至少一张中间页的背景、字体、图片和页边缘正确。
- 没有多出的空白页、孤立页脚或重复封面。
- 文字可搜索/复制，不是整页位图截图。

本地安装了 Poppler 时，可用 `pdfinfo output/deck.pdf` 检查页数，用 `pdftoppm -png output/deck.pdf output/page` 生成逐页预览。没有这些工具时，使用本地 PDF 阅读器人工检查，不要为了验证强行安装系统包。

## PPTX 验证

导出：

```bash
node scripts/export_deck_pptx.mjs --slides /absolute/path/to/slides --out output/deck.pptx
```

验证：

- 命令输出中没有被 skip 的页面；如有失败页，修改 HTML 后重新导出。
- PPTX 页数与 `slides/` 中排序后的 HTML 页数一致。
- 随机选择标题、正文、数字和注解，确认在 PowerPoint/Keynote/LibreOffice Impress 中是可编辑文本。
- 检查字体回落、文本框溢出、图片比例和对齐。
- 不要直接修改生成的 PPTX 来掩盖源 HTML 问题；回到 HTML 修复后重新导出。

## 常见故障

- `Executable doesn't exist`：运行 `npx -y playwright install chromium`。
- `Cannot find package`：在调用脚本的工作目录安装对应 npm 依赖。
- PDF 只有一页：确认使用包内最新 `export_deck_pdf.mjs`，并确认 `<deck-stage>` 的页是直接子 section。
- PDF 出现多余空白页：检查每页高度、overflow 和页脚的 absolute 定位。
- PPTX 尺寸不匹配：使用 `960pt×540pt` / `1280px×720px` HTML 画布。
- PPTX 文字不可编辑：检查文字是否放在支持的文字标签中，且没有被 SVG/图片化。
