import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { chromium } from "playwright";
import { PDFDocument } from "pdf-lib";

function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i += 1) {
    const key = argv[i];
    const value = argv[i + 1];
    if (key === "--html") args.html = value;
    else if (key === "--out") args.out = value;
    else if (key === "--width") args.width = Number(value);
    else if (key === "--height") args.height = Number(value);
    else throw new Error(`Unknown argument: ${key}`);
    i += 1;
  }
  if (!args.html || !args.out) {
    throw new Error(
      "Usage: node scripts/export_deck_pdf.mjs --html index.html --out output/deck.pdf [--width 1920 --height 1080]",
    );
  }
  if ((args.width === undefined) !== (args.height === undefined)) {
    throw new Error("--width and --height must be provided together");
  }
  if (
    args.width !== undefined &&
    (!Number.isFinite(args.width) || !Number.isFinite(args.height) || args.width <= 0 || args.height <= 0)
  ) {
    throw new Error("--width and --height must be positive numbers");
  }
  return args;
}

async function waitForAssets(page) {
  await page.evaluate(async () => {
    if (document.fonts?.ready) await document.fonts.ready;
    await Promise.all(
      Array.from(document.images, (image) => {
        if (image.complete) return undefined;
        return new Promise((resolve) => {
          image.addEventListener("load", resolve, { once: true });
          image.addEventListener("error", resolve, { once: true });
        });
      }),
    );
  });
}

async function prepareDeckStage(page, options) {
  await page.evaluate(({ width, height }) => {
    const stage = document.querySelector("deck-stage");
    const sections = stage ? Array.from(stage.querySelectorAll(":scope > section")) : [];
    if (sections.length === 0) return;

    const style = document.createElement("style");
    style.textContent = `
      @page { size: ${width}px ${height}px; margin: 0; }
      html, body {
        width: ${width}px !important;
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: visible !important;
        background: #fff !important;
      }
      deck-stage { display: none !important; }
      .pdf-export-container { margin: 0; padding: 0; }
    `;
    document.head.appendChild(style);

    const container = document.createElement("div");
    container.className = "pdf-export-container";
    sections.forEach((section) => {
      section.classList.add("active");
      const display = getComputedStyle(section).display;
      section.style.setProperty("display", display === "none" ? "block" : display, "important");
      section.style.setProperty("width", `${width}px`, "important");
      section.style.setProperty("height", `${height}px`, "important");
      section.style.setProperty("position", "relative", "important");
      section.style.setProperty("overflow", "hidden", "important");
      section.style.setProperty("margin", "0", "important");
      section.style.setProperty("break-after", "page", "important");
      section.style.setProperty("page-break-after", "always", "important");
      container.appendChild(section);
    });

    const last = sections.at(-1);
    last.style.setProperty("break-after", "auto", "important");
    last.style.setProperty("page-break-after", "auto", "important");
    document.body.appendChild(container);
  }, options);
}

async function loadPage(page, url) {
  await page.goto(url, { waitUntil: "networkidle" });
  await waitForAssets(page);
}

async function detectPageSize(page, overrides) {
  if (overrides.width && overrides.height) {
    return { width: overrides.width, height: overrides.height };
  }
  return page.evaluate(() => {
    const stage = document.querySelector("deck-stage");
    if (stage) {
      return {
        width: Number(stage.getAttribute("width")) || 1920,
        height: Number(stage.getAttribute("height")) || 1080,
      };
    }
    const bodyStyle = getComputedStyle(document.body);
    const bodyRect = document.body.getBoundingClientRect();
    return {
      width: Math.round(Number.parseFloat(bodyStyle.width) || bodyRect.width || 1920),
      height: Math.round(Number.parseFloat(bodyStyle.height) || bodyRect.height || 1080),
    };
  });
}

async function printLoadedPage(page, options) {
  await prepareDeckStage(page, options);
  await page.emulateMedia({ media: "print" });
  return page.pdf({
    width: `${options.width}px`,
    height: `${options.height}px`,
    printBackground: true,
    preferCSSPageSize: true,
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
  });
}

async function mergePdfs(buffers) {
  const output = await PDFDocument.create();
  for (const buffer of buffers) {
    const source = await PDFDocument.load(buffer);
    const pages = await output.copyPages(source, source.getPageIndices());
    pages.forEach((page) => output.addPage(page));
  }
  return output.save();
}

async function main() {
  const args = parseArgs(process.argv);
  const htmlPath = path.resolve(args.html);
  if (!fs.existsSync(htmlPath) || !fs.statSync(htmlPath).isFile()) {
    throw new Error(`HTML entry not found: ${htmlPath}`);
  }

  const outputPath = path.resolve(args.out);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  const entryUrl = pathToFileURL(htmlPath).href;
  const browser = await chromium.launch({ headless: true });

  try {
    const page = await browser.newPage({
      viewport: { width: args.width || 1920, height: args.height || 1080 },
    });
    await loadPage(page, entryUrl);

    const manifestUrls = await page.evaluate(() => {
      if (!Array.isArray(window.DECK_MANIFEST) || window.DECK_MANIFEST.length === 0) return [];
      return window.DECK_MANIFEST.map((item) => new URL(item.file, document.baseURI).href);
    });

    const buffers = [];
    if (manifestUrls.length > 0) {
      await loadPage(page, manifestUrls[0]);
      const pageSize = await detectPageSize(page, args);
      buffers.push(await printLoadedPage(page, pageSize));
      for (const url of manifestUrls.slice(1)) {
        await loadPage(page, url);
        buffers.push(await printLoadedPage(page, pageSize));
      }
    } else {
      const pageSize = await detectPageSize(page, args);
      buffers.push(await printLoadedPage(page, pageSize));
    }

    const pdf = await mergePdfs(buffers);
    fs.writeFileSync(outputPath, pdf);
    process.stdout.write(`PDF written to ${outputPath}\n`);
  } finally {
    await browser.close();
  }
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exitCode = 1;
});
